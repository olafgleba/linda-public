<article>
  <h2><?php if($page->main_headline) echo $page->main_headline; ?></h2>
  <div class="grid">
    <div class="grid__cell u-1/2-lap-and-up">
      <?php echo $page->main_body_1; ?>
    </div>
    <div class="grid__cell u-1/2-lap-and-up">
      <?php echo $page->main_body_2; ?>
    </div>
  </div>
</article>
