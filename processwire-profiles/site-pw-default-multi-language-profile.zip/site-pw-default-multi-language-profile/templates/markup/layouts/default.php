<article>
  <h2><?php if($page->main_headline) echo $page->main_headline; ?></h2>
  <?php echo $page->main_body; ?>
</article>
