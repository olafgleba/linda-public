<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Default Multi Language Profile", 
	'summary' => "Default Multi Language Profile as a simple start", 
	'screenshot' => ""
	);
