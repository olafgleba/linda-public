<?php

/**
 * Shared functions or variables for all template files
 */



/**
 * This function enables the translation of static template strings.
 * All translation is done in `_strings.php`. More info within the
 * comments of `_strings.php`.
 *
 * @param  string $text       text to translate
 * @param  string $context    Context to allow doubles
 * @param  string $textdomain Point static textdomain
 * @return function           Function for gettext parser
 */
function _t($text, $context = 'Generic', $textdomain = '/site/templates/_strings.php') {
  return _x($text, $context, $textdomain);
}



/**
 * Collect all given languages and print it as a
 * unordered list. Parent (`ul`) is not included
 * to stay flexible with applying appropriate styling
 *
 * @param  array $languages list of available languages
 */
function languageListing($languages) {

  foreach ($languages as $language) {

    $current = '';

    // if this page isn't viewable (active) for the language, skip it
    if(!wire('page')->viewable($language)) continue;

    // determine the "local" URL for this language
    $url = wire('page')->localUrl($language);

    // if language is current user's language, mark it active
    if(wire('user')->language->id == $language->id) $current = "current-lang";

    echo "<li class='$current'><a href='$url'>$language->language_abbreviation</a></li>";
  }
}




/**
 * Print a localized link. This function is meant to be used
 * whenever we have to set static links in multi-language templates
 * by hand.
 *
 * Example:
 *   `<a href="<?php languageLink($user->language, 'media'); ?>">Linktext</a>`
 *
 *   Result:
 *   `<a href="/media/">Linktext</a>` // german (default) page
 *   `<a href="/en/media/">Linktext</a>` // english page
 *
 * @param  string $language current user language
 * @param  string $path     path to page to link to
 */
function languageLink($language, $path) {

    // determine the "local" URL for this language
    $url = wire('page')->localUrl($language);

    // append the "local" URL with given path
    $url .= $path . "/";

    echo $url;
}



/**
 * Build and print alternate link hreflang tags.
 * Function used to be called within the HTML <head />.
 *
 * @param  array $languages list of available languages
 */
function buildHreflang($languages) {

  foreach ($languages as $language) {

    if(!wire('page')->viewable($language)) continue;

    $urls = 'http://'.$_SERVER['HTTP_HOST'].wire('page')->localUrl($language);

    $strings = "<link rel='alternate' href='{$urls}' hreflang='{$language->language_code_language}' />\n";

    echo $strings;
  }
}



/**
 * Breadcrumb
 *
 * Gibt unterschiedliche Klassen aus an den list items
 * abhängig von der Seite, auf der man sich befindet.
 * Dieses Konstrukt ist nur notwendig, wenn die `ul` unabhängig
 * von vorhandenen Seiten gerendert werden soll, e.g. außerhalb
 * der PHP Schleife steht.
 *
 * Wenn wir auf der Homepage sind (e.g. das foreach leer ist),
 * zeige die Startseite als Anfangslink an und gebe (Styling) dem
 * list item die Komponentenklasse `__root` mit. Ansonsten setze
 * die Komponentenklasse `__current`.
 */

function breadcrumb() {

  $page = wire('page');
  $item = '';

  foreach($page->parents() as $parent) {
    $item = "<li><a href='{$parent->url}'>{$parent->title}</a></li>\n";
  }

  if ($page->get("/")) {
    $item .= "<li class='c-breadcrumb__root'>{$page->title}</li>\n";
  } else {
    $item .= "<li class='c-breadcrumb__current'>{$page->title}</li>\n";
  }

  echo $item;
}
