# --- WireDatabaseBackup {"time":"2016-02-23 12:14:46","user":"","dbName":"pw-local","description":"","tables":[],"excludeTables":["pages_drafts","pages_roles","permissions","roles","roles_permissions","users","users_roles","user","role","permission"],"excludeCreateTables":[],"excludeExportTables":["field_roles","field_permissions","field_email","field_pass","caches","session_login_throttle","page_path_history"]}

DROP TABLE IF EXISTS `ProcessRedirects`;
CREATE TABLE `ProcessRedirects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `counter` int(10) unsigned DEFAULT '0',
  `redirect_from` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `redirect_to` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `redirect_from` (`redirect_from`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `caches`;
CREATE TABLE `caches` (
  `name` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expires` (`expires`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_admin_theme`;
CREATE TABLE `field_admin_theme` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_admin_theme` (`pages_id`, `data`) VALUES('41', '148');

DROP TABLE IF EXISTS `field_body_main`;
CREATE TABLE `field_body_main` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `data1024` mediumtext,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_body_main` (`pages_id`, `data`, `data1024`) VALUES('1', '<p>erste</p>', '<p>Englischer Body</p>');
INSERT INTO `field_body_main` (`pages_id`, `data`, `data1024`) VALUES('1026', '<p>Body Einzelseite</p>', '<p>Body singlepage</p>');

DROP TABLE IF EXISTS `field_body_sidebar`;
CREATE TABLE `field_body_sidebar` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `data1024` mediumtext,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_body_sidebar` (`pages_id`, `data`, `data1024`) VALUES('1', '<p>Deutscher Body, zweite Spalte</p>', '');

DROP TABLE IF EXISTS `field_eintrag_votes`;
CREATE TABLE `field_eintrag_votes` (
  `comment_id` int(10) unsigned NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip` varchar(15) NOT NULL DEFAULT '',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`,`ip`,`vote`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_email`;
CREATE TABLE `field_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_fieldset_seo`;
CREATE TABLE `field_fieldset_seo` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_fieldset_seo_end`;
CREATE TABLE `field_fieldset_seo_end` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_headline`;
CREATE TABLE `field_headline` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_headline` (`pages_id`, `data`, `data1024`) VALUES('1', 'Überschrift Homepage', 'Headline homepage');
INSERT INTO `field_headline` (`pages_id`, `data`, `data1024`) VALUES('1026', 'Überschrift Einzelseite', 'Headline singlepage');
INSERT INTO `field_headline` (`pages_id`, `data`, `data1024`) VALUES('27', 'Ups, die Seite wurde nicht gefunden', 'Oops, the page was not found');

DROP TABLE IF EXISTS `field_image`;
CREATE TABLE `field_image` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_language`;
CREATE TABLE `field_language` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language` (`pages_id`, `data`, `sort`) VALUES('40', '1016', '0');
INSERT INTO `field_language` (`pages_id`, `data`, `sort`) VALUES('41', '1016', '0');

DROP TABLE IF EXISTS `field_language_abbreviation`;
CREATE TABLE `field_language_abbreviation` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language_abbreviation` (`pages_id`, `data`, `data1024`) VALUES('1024', 'en', 'en');
INSERT INTO `field_language_abbreviation` (`pages_id`, `data`, `data1024`) VALUES('1016', 'de', 'de');

DROP TABLE IF EXISTS `field_language_code_language`;
CREATE TABLE `field_language_code_language` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language_code_language` (`pages_id`, `data`, `data1024`) VALUES('1016', 'de', 'de');
INSERT INTO `field_language_code_language` (`pages_id`, `data`, `data1024`) VALUES('1024', 'en', 'en');

DROP TABLE IF EXISTS `field_language_files`;
CREATE TABLE `field_language_files` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--templates-admin--default-php.json', '143', '[\"\"]', '2015-12-02 14:38:03', '2015-12-02 14:38:03');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--templates-admin--debug-inc.json', '142', '[\"\"]', '2015-12-02 14:38:03', '2015-12-02 14:38:03');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--textformatter--textformattermarkdownextra--textformattermarkdownextra-module.json', '141', '[\"\"]', '2015-12-02 14:38:03', '2015-12-02 14:38:03');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--textformatter--textformatterentities-module.json', '140', '[\"\"]', '2015-12-02 14:38:03', '2015-12-02 14:38:03');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--system--systemupdater--systemupdater-module.json', '139', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--system--systemnotifications--systemnotificationsconfig-php.json', '138', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--system--systemnotifications--systemnotifications-module.json', '137', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--session--sessionloginthrottle--sessionloginthrottle-module.json', '136', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--session--sessionhandlerdb--sessionhandlerdb-module.json', '135', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--session--sessionhandlerdb--processsessiondb-module.json', '134', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processuser--processuserconfig-php.json', '133', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processtemplate--processtemplateexportimport-php.json', '131', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processuser--processuser-module.json', '132', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processtemplate--processtemplate-module.json', '130', '[\"\"]', '2015-12-02 14:38:02', '2015-12-02 14:38:02');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processrole--processrole-module.json', '129', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processrecentpages--processrecentpages-module.json', '128', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processprofile--processprofile-module.json', '127', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpermission--processpermission-module.json', '126', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageview-module.json', '125', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagesort-module.json', '122', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagetrash-module.json', '123', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagetype--processpagetype-module.json', '124', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagesearch--processpagesearch-module.json', '121', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagelister--processpagelisterbookmarks-php.json', '120', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagelist--processpagelistrender-php.json', '117', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagelister--processpagelister-module.json', '119', '[\"\"]', '2015-12-02 14:38:01', '2015-12-02 14:38:01');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagelist--processpagelistrenderjson-php.json', '118', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagelist--processpagelistactions-php.json', '116', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpagelist--processpagelist-module.json', '115', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageeditlink--processpageeditlink-module.json', '114', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageeditimageselect--processpageeditimageselect-module.json', '113', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageedit--processpageedit-module.json', '112', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageclone-module.json', '110', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageedit--pagebookmarks-php.json', '111', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processpageadd--processpageadd-module.json', '109', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processlogin--processlogin-module.json', '106', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processmodule--processmodule-module.json', '107', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processmodule--processmoduleinstall-php.json', '108', '[\"\"]', '2015-12-02 14:38:00', '2015-12-02 14:38:00');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processlist-module.json', '104', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processlogger--processlogger-module.json', '105', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processhome-module.json', '103', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processfield--processfieldexportimport-php.json', '101', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processforgotpassword-module.json', '102', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processfield--processfield-module.json', '100', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--process--processcommentsmanager--processcommentsmanager-module.json', '99', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--pagerender-module.json', '98', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--pagepaths-module.json', '97', '[\"\"]', '2015-12-02 14:37:59', '2015-12-02 14:37:59');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--markup--markuppagernav--markuppagernav-module.json', '96', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--markup--markuppagefields-module.json', '95', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--languagesupport--processlanguage-module.json', '94', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--languagesupport--languagetabs-module.json', '93', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--languagesupport--languagesupport-module.json', '90', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--languagesupport--languagesupportfields-module.json', '91', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--languagesupport--languagesupportpagenames-module.json', '92', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--languagesupport--languageparser-php.json', '89', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldurl-module.json', '87', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--jquery--jquerywiretabs--jquerywiretabs-module.json', '88', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldtextarea-module.json', '86', '[\"\"]', '2015-12-02 14:37:58', '2015-12-02 14:37:58');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselectmultiple-module.json', '74', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpagename--inputfieldpagename-module.json', '75', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetable-module.json', '76', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetableajax-php.json', '77', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpagetitle--inputfieldpagetitle-module.json', '78', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpassword-module.json', '79', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldradios--inputfieldradios-module.json', '80', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldselect-module.json', '81', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldselectmultiple-module.json', '82', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldselector--inputfieldselector-module.json', '83', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldsubmit--inputfieldsubmit-module.json', '84', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldtext-module.json', '85', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldname-module.json', '70', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselect-module.json', '73', '[\"\"]', '2015-12-02 14:37:57', '2015-12-02 14:37:57');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpageautocomplete--inputfieldpageautocomplete-module.json', '72', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldpage--inputfieldpage-module.json', '71', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldmarkup-module.json', '69', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldinteger-module.json', '68', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldimage--inputfieldimage-module.json', '67', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldicon--inputfieldicon-module.json', '66', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldhidden-module.json', '65', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldfloat-module.json', '63', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldform-module.json', '64', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldfile--inputfieldfile-module.json', '62', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldfieldset-module.json', '61', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldckeditor--inputfieldckeditor-module.json', '58', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldemail-module.json', '60', '[\"\"]', '2015-12-02 14:37:56', '2015-12-02 14:37:56');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfielddatetime--inputfielddatetime-module.json', '59', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldcheckboxes--inputfieldcheckboxes-module.json', '57', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldcheckbox-module.json', '56', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldbutton-module.json', '55', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--inputfield--inputfieldasmselect--inputfieldasmselect-module.json', '54', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypeurl-module.json', '53', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypetextarea-module.json', '52', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypeselector-module.json', '50', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypetext-module.json', '51', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtyperepeater--inputfieldrepeater-module.json', '49', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtyperepeater--fieldtyperepeater-module.json', '48', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypepagetable-module.json', '47', '[\"\"]', '2015-12-02 14:37:55', '2015-12-02 14:37:55');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypeoptions--selectableoptionmanager-php.json', '45', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypepage-module.json', '46', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypeoptions--selectableoptionconfig-php.json', '44', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypemodule-module.json', '42', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypeoptions--fieldtypeoptions-module.json', '43', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypefieldsettabopen-module.json', '38', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypeinteger-module.json', '41', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypefloat-module.json', '40', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypefile-module.json', '39', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypedatetime-module.json', '37', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypecomments--fieldtypecomments-module.json', '35', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypecomments--inputfieldcommentsadmin-module.json', '36', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypecomments--commentfilterakismet-module.json', '31', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypecomments--commentform-php.json', '32', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypecomments--commentlist-php.json', '33', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--fieldtype--fieldtypecomments--commentnotifications-php.json', '34', '[\"\"]', '2015-12-02 14:37:54', '2015-12-02 14:37:54');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--admintheme--adminthemereno--default-php.json', '30', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--admintheme--adminthemereno--adminthemerenohelpers-php.json', '28', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--admintheme--adminthemereno--debug-inc.json', '29', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--admintheme--adminthemereno--adminthemereno-module.json', '27', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--modules--admintheme--adminthemedefault--adminthemedefault-module.json', '26', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--wireupload-php.json', '25', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--wiretempdir-php.json', '24', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--wirehttp-php.json', '23', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--wirecache-php.json', '22', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--sessioncsrf-php.json', '21', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--session-php.json', '20', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--sanitizer-php.json', '19', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--process-php.json', '18', '[\"\"]', '2015-12-02 14:37:53', '2015-12-02 14:37:53');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--permissions-php.json', '17', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--password-php.json', '16', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--paginatedarray-php.json', '15', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--pages-php.json', '14', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--pageimage-php.json', '13', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--modules-php.json', '11', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--modulesduplicates-php.json', '12', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--inputfieldwrapper-php.json', '10', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--inputfield-php.json', '9', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--functions-php.json', '8', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--filevalidatormodule-php.json', '7', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--fields-php.json', '4', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--fieldtype-php.json', '5', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--fieldtypemulti-php.json', '6', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--fieldgroups-php.json', '3', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--admintheme-php.json', '1', '[\"\"]', '2015-12-02 14:37:51', '2015-12-02 14:37:51');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--fieldselectorinfo-php.json', '2', '[\"\"]', '2015-12-02 14:37:52', '2015-12-02 14:37:52');
INSERT INTO `field_language_files` (`pages_id`, `data`, `sort`, `description`, `modified`, `created`) VALUES('1016', 'wire--core--field-php.json', '0', '[\"\"]', '2015-12-02 14:37:51', '2015-12-02 14:37:51');

DROP TABLE IF EXISTS `field_language_files_site`;
CREATE TABLE `field_language_files_site` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_pass`;
CREATE TABLE `field_pass` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` char(40) NOT NULL,
  `salt` char(32) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;

DROP TABLE IF EXISTS `field_permissions`;
CREATE TABLE `field_permissions` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_process`;
CREATE TABLE `field_process` (
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `data` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_process` (`pages_id`, `data`) VALUES('6', '17');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('3', '12');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('8', '12');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('9', '14');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('10', '7');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('11', '47');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('16', '48');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('300', '104');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('21', '50');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('29', '66');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('23', '10');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('304', '138');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('31', '136');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('22', '76');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('30', '68');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('303', '129');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('2', '87');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('302', '121');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('301', '109');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('28', '76');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1007', '150');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1010', '159');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1012', '160');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1015', '163');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1017', '164');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1018', '171');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1021', '179');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1029', '208');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1030', '215');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1035', '228');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1034', '219');
INSERT INTO `field_process` (`pages_id`, `data`) VALUES('1037', '232');

DROP TABLE IF EXISTS `field_roles`;
CREATE TABLE `field_roles` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `field_seo_meta_description`;
CREATE TABLE `field_seo_meta_description` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_seo_meta_description` (`pages_id`, `data`, `data1024`) VALUES('1', '', '');

DROP TABLE IF EXISTS `field_seo_meta_og_description`;
CREATE TABLE `field_seo_meta_og_description` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_meta_og_image`;
CREATE TABLE `field_seo_meta_og_image` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_meta_og_locale`;
CREATE TABLE `field_seo_meta_og_locale` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_meta_og_title`;
CREATE TABLE `field_seo_meta_og_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_meta_og_type`;
CREATE TABLE `field_seo_meta_og_type` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_meta_og_url`;
CREATE TABLE `field_seo_meta_og_url` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_seo_meta_robots`;
CREATE TABLE `field_seo_meta_robots` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_seo_meta_robots` (`pages_id`, `data`, `data1024`) VALUES('1', '', '');

DROP TABLE IF EXISTS `field_seo_meta_sitename`;
CREATE TABLE `field_seo_meta_sitename` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_seo_meta_sitename` (`pages_id`, `data`, `data1024`) VALUES('1', '', '');

DROP TABLE IF EXISTS `field_seo_meta_title`;
CREATE TABLE `field_seo_meta_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_seo_meta_title` (`pages_id`, `data`, `data1024`) VALUES('1', '', '');

DROP TABLE IF EXISTS `field_test`;
CREATE TABLE `field_test` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `field_title`;
CREATE TABLE `field_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `data1024` text,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  KEY `data_exact1024` (`data1024`(255)),
  FULLTEXT KEY `data` (`data`),
  FULLTEXT KEY `data1024` (`data1024`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('11', 'Templates', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('16', 'Fields', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('22', 'Setup', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('3', 'Pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('6', 'Add Page', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('8', 'Tree', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('9', 'Save Sort', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('10', 'Edit', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('21', 'Modules', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('29', 'Users', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('30', 'Roles', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('2', 'Admin', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('7', 'Trash', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('27', '404 Nicht gefunden', '404 Not Found');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('302', 'Insert Link', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('23', 'Login', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('304', 'Profile', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('301', 'Empty Trash', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('300', 'Search', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('303', 'Insert Image', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('28', 'Access', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('31', 'Permissions', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('32', 'Edit pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('34', 'Delete pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('35', 'Move pages (change parent)', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('36', 'View pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('50', 'Sort child pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('51', 'Change templates on pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('52', 'Administer users', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('53', 'User can update profile/password', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('54', 'Lock or unlock a page', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1', 'Startseite', 'Homepage');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1006', 'Use Page Lister', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1007', 'Find', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1010', 'Recent', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1011', 'Can see recently edited pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1012', 'Logs', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1013', 'Can view system logs', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1014', 'Can manage system logs', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1015', 'Languages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1016', 'Deutsch', 'German');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1017', 'Language Translator', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1018', 'Upgrades', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1020', 'Repeaters', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1021', 'Clone', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1022', 'Clone a page', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1023', 'Clone a tree of pages', NULL);
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1024', 'Englisch', 'English');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1025', 'Framework', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1026', 'Einzelseite', 'Singlepage');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1029', 'Export Site Profile', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1030', 'Comments', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1036', 'View Batcher Page', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1035', 'Batcher', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1034', 'Redirects', '');
INSERT INTO `field_title` (`pages_id`, `data`, `data1024`) VALUES('1037', 'Redirects', '');

DROP TABLE IF EXISTS `fieldgroups`;
CREATE TABLE `fieldgroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

INSERT INTO `fieldgroups` (`id`, `name`) VALUES('2', 'admin');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('3', 'user');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('4', 'role');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('5', 'permission');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('1', 'home');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('97', 'language');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('98', 'framework');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('100', 'error');
INSERT INTO `fieldgroups` (`id`, `name`) VALUES('101', 'default');

DROP TABLE IF EXISTS `fieldgroups_fields`;
CREATE TABLE `fieldgroups_fields` (
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fields_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`fieldgroups_id`,`fields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('2', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '103', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '99', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('4', '5', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('5', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '4', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '97', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('98', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '102', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '92', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('3', '3', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('100', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '124', '16', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('100', '101', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '106', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('2', '2', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('100', '100', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('97', '98', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '120', '9', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '113', '10', '{\"columnWidth\":50}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '116', '11', '{\"columnWidth\":50,\"maxlength\":2048}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '114', '12', '{\"columnWidth\":50,\"placeholder\":\"Canonical URL...\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '117', '13', '{\"columnWidth\":50,\"maxlength\":2048,\"placeholder\":\"Absolute URL...\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '115', '14', '{\"columnWidth\":50,\"maxlength\":2048}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '118', '15', '{\"columnWidth\":50,\"maxlength\":2048,\"placeholder\":\"de_DE\"}');
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '124', '16', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '112', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '125', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '111', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '123', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '105', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '104', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '100', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '101', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '118', '15', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '115', '14', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '117', '13', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '114', '12', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '116', '11', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '113', '10', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '120', '9', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '112', '8', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '125', '7', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '111', '6', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '123', '5', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '105', '4', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '104', '3', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '100', '2', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '101', '1', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('101', '1', '0', NULL);
INSERT INTO `fieldgroups_fields` (`fieldgroups_id`, `fields_id`, `sort`, `data`) VALUES('1', '1', '0', NULL);

DROP TABLE IF EXISTS `fields`;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET ascii NOT NULL,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('1', 'FieldtypePageTitleLanguage', 'title', '13', 'Title', '{\"required\":1,\"textformatters\":[\"TextformatterEntities\"],\"size\":0,\"maxlength\":255,\"label1024\":\"Titel\",\"send_templates\":[44,2,1,43,5]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('2', 'FieldtypeModule', 'process', '25', 'Process', '{\"description\":\"The process that is executed on this page. Since this is mostly used by ProcessWire internally, it is recommended that you don\'t change the value of this unless adding your own pages in the admin.\",\"collapsed\":1,\"required\":1,\"moduleTypes\":[\"Process\"],\"permanent\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('3', 'FieldtypePassword', 'pass', '24', 'Set Password', '{\"collapsed\":1,\"size\":50,\"maxlength\":128}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('5', 'FieldtypePage', 'permissions', '24', 'Permissions', '{\"derefAsPage\":0,\"parent_id\":31,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldCheckboxes\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('4', 'FieldtypePage', 'roles', '24', 'Roles', '{\"derefAsPage\":0,\"parent_id\":30,\"labelFieldName\":\"name\",\"inputfield\":\"InputfieldCheckboxes\",\"description\":\"User will inherit the permissions assigned to each role. You may assign multiple roles to a user. When accessing a page, the user will only inherit permissions from the roles that are also assigned to the page\'s template.\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('92', 'FieldtypeEmail', 'email', '9', 'E-Mail Address', '{\"size\":70,\"maxlength\":255}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('97', 'FieldtypeFile', 'language_files_site', '24', 'Site Translation Files', '{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for translations specific to your site (like files in \\/site\\/templates\\/ for example).\",\"descriptionRows\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('98', 'FieldtypeFile', 'language_files', '24', 'Core Translation Files', '{\"extensions\":\"json\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for [language packs](http:\\/\\/modules.processwire.com\\/categories\\/language-pack\\/). To delete all files, double-click the trash can for any file, then save.\",\"descriptionRows\":0,\"fileSchema\":2}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('99', 'FieldtypePage', 'language', '24', 'Language', '{\"derefAsPage\":1,\"parent_id\":1015,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldRadios\",\"required\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('100', 'FieldtypeTextareaLanguage', 'body_main', '0', 'Inhalte (Main)', '{\"label1024\":\"Content\",\"inputfieldClass\":\"InputfieldCKEditor\",\"contentType\":1,\"langBlankInherit\":0,\"collapsed\":0,\"rows\":15,\"toolbar\":\"Format, Styles, -, Bold, Italic, -,\\nRemoveFormat, -,\\nNumberedList, BulletedList, -,\\nHorizontalRule, -,\\nPWLink, Unlink, -, \\nSourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[4,8],\"extraAllowedContent\":\"span(*)\\ndiv(*)\",\"stylesSet\":\"project-styles:\\/site\\/modules\\/InputfieldCKEditor\\/project-styles.js\",\"contentsCss\":\"\\/site\\/templates\\/assets\\/css\\/styles.min.editor.css\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('104', 'FieldtypeTextareaLanguage', 'body_sidebar', '0', 'Inhalte (Sidebar)', '{\"label1024\":\"Content (Second Column)\",\"inputfieldClass\":\"InputfieldCKEditor\",\"contentType\":1,\"langBlankInherit\":0,\"collapsed\":0,\"rows\":10,\"toolbar\":\"Format, Styles, -, Bold, Italic, -,\\nRemoveFormat, -,\\nNumberedList, BulletedList, -,\\nHorizontalRule, -,\\nPWLink, Unlink, -, \\nSourcedialog\",\"inlineMode\":0,\"useACF\":1,\"usePurifier\":1,\"formatTags\":\"p;h2;h3;h4\",\"extraPlugins\":[\"pwimage\",\"pwlink\",\"sourcedialog\"],\"removePlugins\":\"image,magicline\",\"toggles\":[4,8],\"extraAllowedContent\":\"span(*)\\ndiv(*)\",\"stylesSet\":\"project-styles:\\/site\\/modules\\/InputfieldCKEditor\\/project-styles.js\",\"contentsCss\":\"\\/site\\/templates\\/assets\\/css\\/styles.min.editor.css\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('101', 'FieldtypeTextLanguage', 'headline', '0', 'Headline', '{\"label1024\":\"\\u00dcberschrift\",\"langBlankInherit\":0,\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"send_templates\":[1]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('102', 'FieldtypeTextLanguage', 'language_abbreviation', '0', 'Länderkürzel (Pfade, Urls)', '{\"label1024\":\"Abbreviation\",\"langBlankInherit\":1,\"collapsed\":0,\"size\":0,\"maxlength\":2048,\"send_templates\":[43]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('103', 'FieldtypeModule', 'admin_theme', '8', 'Admin Theme', '{\"moduleTypes\":[\"AdminTheme\"],\"labelField\":\"title\",\"inputfieldClass\":\"InputfieldRadios\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('105', 'FieldtypeImage', 'image', '0', 'Fotos', '{\"extensions\":\"jpg jpeg png\",\"maxFiles\":1,\"outputFormat\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\",\"descriptionRows\":0,\"defaultGrid\":0,\"maxReject\":0,\"fileSchema\":2,\"collapsed\":0,\"description\":\"Auf die Einstellung (Detail Tab) des Feldes achten. Wenn die Maximale Anzahl auf \'0\' gesetzt aber nur 1 Image vorhanden ist, muss darauf per $image->first->url zugegriffen werden. Ansonsten bekommt man einen 403 Fehler, der augenscheinlich ein Rechteproblem ist (was es nicht ist).\",\"adminThumbs\":1}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('106', 'FieldtypeTextLanguage', 'language_code_language', '0', 'Ländercode (ISO 639-1)', '{\"label1024\":\"Country Code (ISO 639-1)\",\"langBlankInherit\":1,\"collapsed\":0,\"size\":0,\"maxlength\":2048}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('107', 'FieldtypeTextarea', 'test', '0', 'markitup', '{\"inputfieldClass\":\"InputfieldMarkItUp\",\"contentType\":0,\"collapsed\":0,\"rows\":15,\"send_templates\":[1]}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('125', 'FieldtypeTextLanguage', 'seo_meta_sitename', '0', 'Meta Seitenname', '{\"langBlankInherit\":0,\"collapsed\":2,\"columnWidth\":50,\"size\":0,\"maxlength\":2048,\"placeholder\":\"default: $config_sitename in _init.php\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('111', 'FieldtypeTextLanguage', 'seo_meta_title', '0', 'Meta Titel', '{\"label1024\":\"Meta Title\",\"textformatters\":[\"TextformatterEntities\"],\"langBlankInherit\":0,\"collapsed\":2,\"size\":0,\"maxlength\":2048,\"columnWidth\":50,\"placeholder\":\"default: $page->title\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('112', 'FieldtypeTextLanguage', 'seo_meta_description', '0', 'Meta Beschreibung', '{\"label1024\":\"Meta Description\",\"langBlankInherit\":0,\"collapsed\":2,\"size\":0,\"maxlength\":2048,\"placeholder\":\"default: $config_description in _init.php\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('113', 'FieldtypeTextLanguage', 'seo_meta_og_title', '0', 'og:title', '{\"label1024\":\"og:title\",\"langBlankInherit\":0,\"collapsed\":2,\"size\":0,\"maxlength\":2048,\"columnWidth\":50}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('114', 'FieldtypeTextLanguage', 'seo_meta_og_url', '0', 'og:url', '{\"label1024\":\"og:url\",\"langBlankInherit\":0,\"collapsed\":2,\"size\":0,\"maxlength\":2048,\"columnWidth\":50}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('115', 'FieldtypeTextLanguage', 'seo_meta_og_type', '0', 'og:type', '{\"label1024\":\"og:type\",\"langBlankInherit\":0,\"collapsed\":2,\"columnWidth\":50,\"size\":0,\"maxlength\":2048}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('116', 'FieldtypeTextLanguage', 'seo_meta_og_description', '0', 'og:description', '{\"label1024\":\"og:description\",\"langBlankInherit\":0,\"collapsed\":2,\"columnWidth\":50,\"size\":0,\"maxlength\":2048}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('117', 'FieldtypeTextLanguage', 'seo_meta_og_image', '0', 'og:image', '{\"label1024\":\"og:image\",\"langBlankInherit\":0,\"collapsed\":2,\"columnWidth\":50,\"size\":0,\"maxlength\":2048}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('118', 'FieldtypeTextLanguage', 'seo_meta_og_locale', '0', 'og:locale', '{\"label1024\":\"og:locale\",\"langBlankInherit\":0,\"collapsed\":2,\"columnWidth\":50,\"size\":0,\"maxlength\":2048}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('120', 'FieldtypeTextLanguage', 'seo_meta_robots', '0', 'Meta Index (follow, no-follow)', '{\"langBlankInherit\":0,\"collapsed\":2,\"size\":0,\"maxlength\":2048,\"placeholder\":\"default: index,follow\"}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('123', 'FieldtypeFieldsetTabOpen', 'fieldset_seo', '0', 'SEO', '{\"collapsed\":0}');
INSERT INTO `fields` (`id`, `type`, `name`, `flags`, `label`, `data`) VALUES('124', 'FieldtypeFieldsetClose', 'fieldset_seo_END', '0', 'Close an open fieldset', '{\"description\":\"This field was added automatically to accompany fieldset \'fieldset_seo\'. It should be placed in your template\\/fieldgroup wherever you want the fieldset to end.\"}');

DROP TABLE IF EXISTS `fieldtype_options`;
CREATE TABLE `fieldtype_options` (
  `fields_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `title` text,
  `value` varchar(255) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fields_id`,`option_id`),
  UNIQUE KEY `title` (`title`(255),`fields_id`),
  KEY `value` (`value`,`fields_id`),
  KEY `sort` (`sort`,`fields_id`),
  FULLTEXT KEY `title_value` (`title`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM AUTO_INCREMENT=235 DEFAULT CHARSET=utf8;

INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('1', 'FieldtypeTextarea', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('2', 'FieldtypeNumber', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('3', 'FieldtypeText', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('4', 'FieldtypePage', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('30', 'InputfieldForm', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('6', 'FieldtypeFile', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('7', 'ProcessPageEdit', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('10', 'ProcessLogin', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('12', 'ProcessPageList', '0', '{\"pageLabelField\":\"title\",\"paginationLimit\":25,\"limit\":50}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('121', 'ProcessPageEditLink', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('14', 'ProcessPageSort', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('15', 'InputfieldPageListSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('117', 'JqueryUI', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('17', 'ProcessPageAdd', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('125', 'SessionLoginThrottle', '11', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('122', 'InputfieldPassword', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('25', 'InputfieldAsmSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('116', 'JqueryCore', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('27', 'FieldtypeModule', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('28', 'FieldtypeDatetime', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('29', 'FieldtypeEmail', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('108', 'InputfieldURL', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('32', 'InputfieldSubmit', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('33', 'InputfieldWrapper', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('34', 'InputfieldText', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('35', 'InputfieldTextarea', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('36', 'InputfieldSelect', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('37', 'InputfieldCheckbox', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('38', 'InputfieldCheckboxes', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('39', 'InputfieldRadios', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('40', 'InputfieldHidden', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('41', 'InputfieldName', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('43', 'InputfieldSelectMultiple', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('45', 'JqueryWireTabs', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('46', 'ProcessPage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('47', 'ProcessTemplate', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('48', 'ProcessField', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('50', 'ProcessModule', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('114', 'PagePermissions', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('97', 'FieldtypeCheckbox', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('115', 'PageRender', '3', '{\"clearCache\":1}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('55', 'InputfieldFile', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('56', 'InputfieldImage', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('57', 'FieldtypeImage', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('60', 'InputfieldPage', '0', '{\"inputfieldClasses\":[\"InputfieldSelect\",\"InputfieldSelectMultiple\",\"InputfieldCheckboxes\",\"InputfieldRadios\",\"InputfieldAsmSelect\",\"InputfieldPageListSelect\",\"InputfieldPageListSelectMultiple\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('61', 'TextformatterEntities', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('66', 'ProcessUser', '0', '{\"showFields\":[\"name\",\"email\",\"roles\",\"language\"],\"maxAjaxQty\":25}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('67', 'MarkupAdminDataTable', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('68', 'ProcessRole', '0', '{\"showFields\":[\"name\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('76', 'ProcessList', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('78', 'InputfieldFieldset', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('79', 'InputfieldMarkup', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('80', 'InputfieldEmail', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('89', 'FieldtypeFloat', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('83', 'ProcessPageView', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('84', 'FieldtypeInteger', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('85', 'InputfieldInteger', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('86', 'InputfieldPageName', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('87', 'ProcessHome', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('90', 'InputfieldFloat', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('94', 'InputfieldDatetime', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('98', 'MarkupPagerNav', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('129', 'ProcessPageEditImageSelect', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('103', 'JqueryTableSorter', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('104', 'ProcessPageSearch', '1', '{\"searchFields\":\"title\",\"displayField\":\"title path\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('105', 'FieldtypeFieldsetOpen', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('106', 'FieldtypeFieldsetClose', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('107', 'FieldtypeFieldsetTabOpen', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('109', 'ProcessPageTrash', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('111', 'FieldtypePageTitle', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('112', 'InputfieldPageTitle', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('113', 'MarkupPageArray', '3', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('131', 'InputfieldButton', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('133', 'FieldtypePassword', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('134', 'ProcessPageType', '1', '{\"showFields\":[]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('135', 'FieldtypeURL', '1', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('136', 'ProcessPermission', '1', '{\"showFields\":[\"name\",\"title\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('137', 'InputfieldPageListSelectMultiple', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('138', 'ProcessProfile', '1', '{\"profileFields\":[\"pass\",\"email\",\"language\",\"admin_theme\"]}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('139', 'SystemUpdater', '1', '{\"systemVersion\":14,\"coreVersion\":\"2.7.2\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('148', 'AdminThemeDefault', '10', '{\"colors\":\"classic\"}', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('149', 'InputfieldSelector', '10', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('150', 'ProcessPageLister', '0', '', '0000-00-00 00:00:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('151', 'JqueryMagnific', '1', '', '2014-07-21 07:21:45');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('155', 'InputfieldCKEditor', '0', '', '2014-07-25 10:26:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('156', 'MarkupHTMLPurifier', '0', '', '2014-07-25 10:26:17');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('159', 'ProcessRecentPages', '1', '', '2015-05-20 02:50:57');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('160', 'ProcessLogger', '1', '', '2015-05-20 02:51:15');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('161', 'InputfieldIcon', '0', '', '2015-05-20 02:51:16');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('162', 'LanguageSupport', '3', '{\"languagesPageID\":1015,\"defaultLanguagePageID\":1016,\"otherLanguagePageIDs\":[1024],\"languageTranslatorPageID\":1017}', '2015-06-05 08:27:12');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('163', 'ProcessLanguage', '1', '', '2015-06-05 08:27:12');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('164', 'ProcessLanguageTranslator', '1', '', '2015-06-05 08:27:12');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('165', 'LanguageSupportFields', '3', '', '2015-06-05 08:28:40');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('166', 'FieldtypeTextLanguage', '1', '', '2015-06-05 08:28:40');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('167', 'FieldtypePageTitleLanguage', '1', '', '2015-06-05 08:28:41');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('168', 'FieldtypeTextareaLanguage', '1', '', '2015-06-05 08:28:41');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('169', 'LanguageSupportPageNames', '3', '{\"moduleVersion\":9,\"pageNumUrlPrefix1016\":\"page\",\"pageNumUrlPrefix1024\":\"seite\",\"useHomeSegment\":\"0\"}', '2015-06-05 08:28:58');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('170', 'LanguageTabs', '11', '', '2015-06-05 08:29:41');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('171', 'ProcessWireUpgrade', '1', '', '2015-06-05 08:31:20');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('172', 'ProcessWireUpgradeCheck', '11', '{\"useLoginHook\":\"0\"}', '2015-06-05 08:31:20');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('175', 'WireMailSmtp', '0', '{\"localhost\":\"localhost\",\"smtp_host\":\"\",\"smtp_port\":25,\"smtp_start_tls\":\"\",\"smtp_ssl\":\"\",\"smtp_user\":\"\",\"smtp_password\":\"\",\"authentication_mechanism\":\"\",\"realm\":\"\",\"workstation\":\"\",\"sender_email\":\"\",\"sender_name\":\"\",\"sender_reply\":\"\",\"sender_errors_to\":\"\",\"sender_signature\":\"\",\"sender_signature_html\":\"\",\"send_sender_signature\":\"1\",\"valid_recipients\":\"\",\"extra_headers\":\"\",\"smtp_certificate\":\"\"}', '2015-06-29 13:18:46');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('176', 'FieldtypeRepeater', '3', '{\"repeatersRootPageID\":1020}', '2015-06-29 13:20:24');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('177', 'InputfieldRepeater', '0', '', '2015-06-29 13:20:24');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('178', 'FieldtypeOptions', '1', '', '2015-06-29 13:20:40');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('179', 'ProcessPageClone', '11', '', '2015-06-29 13:23:39');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('205', 'EditorSkinLightwire', '0', '', '2015-09-13 22:54:15');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('183', 'ProcessForgotPassword', '1', '{\"emailFrom\":\"og@olafgleba.de\"}', '2015-07-18 02:21:00');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('206', 'FieldtypePageTable', '3', '', '2015-09-13 23:00:01');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('207', 'InputfieldPageTable', '0', '', '2015-09-13 23:00:01');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('216', 'InputfieldMarkItUp', '0', '', '2016-01-09 21:56:52');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('211', 'TextformatterMarkdownExtra', '1', '', '2015-09-30 01:56:52');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('212', 'FieldtypeComments', '1', '', '2015-10-15 12:28:34');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('228', 'ProcessBatcher', '1', '', '2016-02-17 01:20:52');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('234', 'PagePathHistory', '3', '', '2016-02-23 11:11:22');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('218', 'JqueryFancybox', '1', '', '2016-02-17 00:42:38');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('232', 'ProcessRedirects', '3', '', '2016-02-17 11:42:35');
INSERT INTO `modules` (`id`, `class`, `flags`, `data`, `created`) VALUES('233', 'InputfieldCommentsAdmin', '0', '', '2016-02-18 00:11:53');

DROP TABLE IF EXISTS `page_path_history`;
CREATE TABLE `page_path_history` (
  `path` varchar(255) NOT NULL,
  `pages_id` int(10) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`path`),
  KEY `pages_id` (`pages_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `templates_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET ascii NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `published` datetime DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `name1024` varchar(128) CHARACTER SET ascii DEFAULT NULL,
  `status1024` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_parent_id` (`name`,`parent_id`),
  UNIQUE KEY `name1024_parent_id` (`name1024`,`parent_id`),
  KEY `parent_id` (`parent_id`),
  KEY `templates_id` (`templates_id`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `status` (`status`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=1038 DEFAULT CHARSET=utf8;

INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1', '0', '1', '', '9', '2016-02-23 00:31:31', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0', 'en', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('2', '1', '2', 'processwire', '1035', '2015-07-22 02:46:43', '40', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '6', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('3', '2', '2', 'page', '21', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('6', '3', '2', 'add', '21', '2015-12-01 12:03:14', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('7', '1', '2', 'trash', '1039', '2011-08-14 22:04:52', '41', '2010-02-07 05:29:39', '2', '2010-02-07 05:29:39', '7', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('8', '3', '2', 'list', '1045', '2016-02-17 00:37:23', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '1', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('9', '3', '2', 'sort', '1047', '2011-03-29 21:37:06', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '2', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('10', '3', '2', 'edit', '1045', '2016-02-17 00:37:23', '41', '0000-00-00 00:00:00', '2', '0000-00-00 00:00:00', '3', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('11', '22', '2', 'template', '21', '2011-03-29 21:37:06', '41', '2010-02-01 11:04:54', '2', '2010-02-01 11:04:54', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('16', '22', '2', 'field', '21', '2011-03-29 21:37:06', '41', '2010-02-01 12:44:07', '2', '2010-02-01 12:44:07', '2', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('21', '2', '2', 'module', '21', '2011-03-29 21:37:06', '41', '2010-02-02 10:02:24', '2', '2010-02-02 10:02:24', '2', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('22', '2', '2', 'setup', '21', '2011-03-29 21:37:06', '41', '2010-02-09 12:16:59', '2', '2010-02-09 12:16:59', '1', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('23', '2', '2', 'login', '1035', '2011-05-03 23:38:10', '41', '2010-02-17 09:59:39', '2', '2010-02-17 09:59:39', '4', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('27', '1', '46', 'seite-nicht-gefunden', '1035', '2015-07-18 01:26:53', '41', '2010-06-03 06:53:03', '3', '2010-06-03 06:53:03', '5', 'page-not-found', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('28', '2', '2', 'access', '13', '2011-05-03 23:38:10', '41', '2011-03-19 19:14:20', '2', '2011-03-19 19:14:20', '3', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('29', '28', '2', 'users', '29', '2011-04-05 00:39:08', '41', '2011-03-19 19:15:29', '2', '2011-03-19 19:15:29', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('30', '28', '2', 'roles', '29', '2011-04-05 00:38:39', '41', '2011-03-19 19:15:45', '2', '2011-03-19 19:15:45', '1', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('31', '28', '2', 'permissions', '29', '2011-04-05 00:53:52', '41', '2011-03-19 19:16:00', '2', '2011-03-19 19:16:00', '2', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('32', '31', '5', 'page-edit', '25', '2011-09-06 15:34:24', '41', '2011-03-19 19:17:03', '2', '2011-03-19 19:17:03', '2', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('34', '31', '5', 'page-delete', '25', '2011-09-06 15:34:33', '41', '2011-03-19 19:17:23', '2', '2011-03-19 19:17:23', '3', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('35', '31', '5', 'page-move', '25', '2011-09-06 15:34:48', '41', '2011-03-19 19:17:41', '2', '2011-03-19 19:17:41', '4', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('36', '31', '5', 'page-view', '25', '2011-09-06 15:34:14', '41', '2011-03-19 19:17:57', '2', '2011-03-19 19:17:57', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('37', '30', '4', 'guest', '25', '2011-04-05 01:37:19', '41', '2011-03-19 19:18:41', '2', '2011-03-19 19:18:41', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('38', '30', '4', 'superuser', '25', '2015-12-01 13:13:20', '41', '2011-03-19 19:18:55', '2', '2011-03-19 19:18:55', '1', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('41', '29', '3', 'og', '1', '2015-07-22 02:46:43', '40', '2011-03-19 19:41:26', '2', '2011-03-19 19:41:26', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('40', '29', '3', 'guest', '25', '2015-07-17 14:54:50', '41', '2011-03-20 17:31:59', '2', '2011-03-20 17:31:59', '1', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('50', '31', '5', 'page-sort', '25', '2011-09-06 15:34:58', '41', '2011-03-26 22:04:50', '41', '2011-03-26 22:04:50', '5', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('51', '31', '5', 'page-template', '25', '2011-09-06 15:35:09', '41', '2011-03-26 22:25:31', '41', '2011-03-26 22:25:31', '6', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('52', '31', '5', 'user-admin', '25', '2011-09-06 15:35:42', '41', '2011-03-30 00:06:47', '41', '2011-03-30 00:06:47', '10', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('53', '31', '5', 'profile-edit', '1', '2011-08-16 22:32:48', '41', '2011-04-26 00:02:22', '41', '2011-04-26 00:02:22', '13', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('54', '31', '5', 'page-lock', '1', '2011-08-15 17:48:12', '41', '2011-08-15 17:45:48', '41', '2011-08-15 17:45:48', '8', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('300', '3', '2', 'search', '1045', '2011-03-29 21:37:06', '41', '2010-08-04 05:23:59', '2', '2010-08-04 05:23:59', '5', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('301', '3', '2', 'trash', '1047', '2011-03-29 21:37:06', '41', '2010-09-28 05:39:30', '2', '2010-09-28 05:39:30', '5', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('302', '3', '2', 'link', '1041', '2011-03-29 21:37:06', '41', '2010-10-01 05:03:56', '2', '2010-10-01 05:03:56', '6', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('303', '3', '2', 'image', '1041', '2011-03-29 21:37:06', '41', '2010-10-13 03:56:48', '2', '2010-10-13 03:56:48', '7', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('304', '2', '2', 'profile', '1025', '2011-05-03 23:38:10', '41', '2011-04-25 23:57:18', '41', '2011-04-25 23:57:18', '5', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1006', '31', '5', 'page-lister', '1', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '9', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1007', '3', '2', 'lister', '1', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '40', '2014-07-20 09:00:38', '8', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1010', '3', '2', 'recent-pages', '1', '2015-05-20 02:50:57', '40', '2015-05-20 02:50:57', '40', '2015-05-20 02:50:57', '9', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1011', '31', '5', 'page-edit-recent', '1', '2015-05-20 02:50:57', '40', '2015-05-20 02:50:57', '40', '2015-05-20 02:50:57', '10', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1012', '22', '2', 'logs', '1', '2015-05-20 02:51:15', '40', '2015-05-20 02:51:15', '40', '2015-05-20 02:51:15', '2', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1013', '31', '5', 'logs-view', '1', '2015-05-20 02:51:15', '40', '2015-05-20 02:51:15', '40', '2015-05-20 02:51:15', '11', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1014', '31', '5', 'logs-edit', '1', '2015-05-20 02:51:15', '40', '2015-05-20 02:51:15', '40', '2015-05-20 02:51:15', '12', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1015', '22', '2', 'languages', '16', '2015-06-05 08:27:12', '41', '2015-06-05 08:27:12', '41', '2015-06-05 08:27:12', '3', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1016', '1015', '43', 'default', '16', '2015-12-02 14:38:14', '41', '2015-06-05 08:27:12', '41', '2015-06-05 08:27:12', '0', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1017', '22', '2', 'language-translator', '1040', '2015-06-05 08:27:12', '41', '2015-06-05 08:27:12', '41', '2015-06-05 08:27:12', '4', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1018', '22', '2', 'upgrades', '1', '2015-06-05 08:31:20', '41', '2015-06-05 08:31:20', '41', '2015-06-05 08:31:20', '5', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1020', '2', '2', 'repeaters', '1036', '2015-06-29 13:20:24', '41', '2015-06-29 13:20:24', '41', '2015-06-29 13:20:24', '6', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1021', '3', '2', 'clone', '1024', '2015-06-29 13:23:39', '41', '2015-06-29 13:23:39', '41', '2015-06-29 13:23:39', '10', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1022', '31', '5', 'page-clone', '1', '2015-06-29 13:23:39', '41', '2015-06-29 13:23:39', '41', '2015-06-29 13:23:39', '13', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1023', '31', '5', 'page-clone-tree', '1', '2015-06-29 13:23:39', '41', '2015-06-29 13:23:39', '41', '2015-06-29 13:23:39', '14', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1024', '1015', '43', 'english', '1', '2015-12-02 14:36:11', '41', '2015-06-29 13:25:41', '41', '2015-06-29 13:25:41', '1', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1025', '1', '44', 'framework', '1025', '2015-12-01 13:23:24', '41', '2015-06-30 22:54:53', '41', '2015-06-30 22:54:53', '4', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1026', '1', '47', 'einzelseite', '1', '2015-12-02 13:36:21', '41', '2015-07-16 18:41:21', '41', '2015-07-16 18:41:21', '3', 'singlepage', '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1030', '7', '2', '1030.22.7_comments', '8193', '2016-02-18 00:12:08', '41', '2015-10-15 12:30:03', '41', '2015-10-15 12:30:03', '7', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1036', '31', '5', 'batcher', '1', '2016-02-17 01:20:52', '41', '2016-02-17 01:20:52', '41', '2016-02-17 01:20:52', '16', NULL, '1');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1035', '22', '2', 'batcher', '1', '2016-02-17 01:20:52', '41', '2016-02-17 01:20:52', '41', '2016-02-17 01:20:52', '9', NULL, '0');
INSERT INTO `pages` (`id`, `parent_id`, `templates_id`, `name`, `status`, `modified`, `modified_users_id`, `created`, `created_users_id`, `published`, `sort`, `name1024`, `status1024`) VALUES('1037', '22', '2', 'redirects', '1', '2016-02-17 11:42:35', '41', '2016-02-17 11:42:35', '41', '2016-02-17 11:42:35', '9', NULL, '0');

DROP TABLE IF EXISTS `pages_access`;
CREATE TABLE `pages_access` (
  `pages_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pages_id`),
  KEY `templates_id` (`templates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('37', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('38', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('32', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('34', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('35', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('36', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('50', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('51', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('52', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('53', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('54', '2', '2011-09-06 12:10:09');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1006', '2', '2014-07-20 09:00:38');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1011', '2', '2015-05-20 02:50:57');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1013', '2', '2015-05-20 02:51:15');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1014', '2', '2015-05-20 02:51:15');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1016', '2', '2015-06-05 08:27:12');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1022', '2', '2015-06-29 13:23:39');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1023', '2', '2015-06-29 13:23:39');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1024', '2', '2015-06-29 13:25:41');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1025', '1', '2015-06-30 22:54:53');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1026', '1', '2015-07-17 15:20:25');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('27', '1', '2015-07-18 01:22:51');
INSERT INTO `pages_access` (`pages_id`, `templates_id`, `ts`) VALUES('1036', '2', '2016-02-17 01:20:52');

DROP TABLE IF EXISTS `pages_parents`;
CREATE TABLE `pages_parents` (
  `pages_id` int(10) unsigned NOT NULL,
  `parents_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`parents_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('2', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('3', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('3', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('7', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('22', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('22', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('28', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('28', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('29', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('30', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('31', '28');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1015', '1');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1015', '2');
INSERT INTO `pages_parents` (`pages_id`, `parents_id`) VALUES('1015', '22');

DROP TABLE IF EXISTS `pages_sortfields`;
CREATE TABLE `pages_sortfields` (
  `pages_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sortfield` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `process_forgot_password`;
CREATE TABLE `process_forgot_password` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `token` char(32) NOT NULL,
  `ts` int(10) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`),
  KEY `ts` (`ts`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;


DROP TABLE IF EXISTS `session_login_throttle`;
CREATE TABLE `session_login_throttle` (
  `name` varchar(128) NOT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_attempt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ascii NOT NULL,
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  `cache_time` mediumint(9) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fieldgroups_id` (`fieldgroups_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('2', 'admin', '2', '8', '0', '{\"useRoles\":1,\"parentTemplates\":[2],\"allowPageNum\":1,\"redirectLogin\":23,\"slashUrls\":1,\"noGlobal\":1,\"modified\":1412322508}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('3', 'user', '3', '8', '0', '{\"useRoles\":1,\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"User\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('4', 'role', '4', '8', '0', '{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Role\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('5', 'permission', '5', '8', '0', '{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"guestSearchable\":1,\"pageClass\":\"Permission\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('1', 'home', '1', '0', '0', '{\"useRoles\":1,\"noParents\":1,\"slashUrls\":1,\"modified\":1456183073,\"roles\":[37]}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('43', 'language', '97', '8', '0', '{\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Language\",\"pageLabelField\":\"name\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noChangeTemplate\":1,\"noUnpublish\":1,\"nameContentTab\":1,\"modified\":1443291572}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('44', 'framework', '98', '0', '0', '{\"slashUrls\":1,\"modified\":1442022832}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('46', 'error', '100', '0', '0', '{\"slashUrls\":1,\"modified\":1442175687}');
INSERT INTO `templates` (`id`, `name`, `fieldgroups_id`, `flags`, `cache_time`, `data`) VALUES('47', 'default', '101', '0', '0', '{\"slashUrls\":1,\"modified\":1456222103}');

UPDATE pages SET created_users_id=41, modified_users_id=41, created=NOW(), modified=NOW();

# --- /WireDatabaseBackup {"numTables":38,"numCreateTables":45,"numInserts":566,"numSeconds":0}