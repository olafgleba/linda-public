<?php

/**
 * Shared functions or variables for all template files
 *
 */

// Remember
// $pages-> => wire('pages')->
