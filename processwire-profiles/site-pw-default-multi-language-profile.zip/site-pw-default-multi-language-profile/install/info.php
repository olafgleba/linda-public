<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Default Profile Multi-Language", 
	'summary' => "Default profile for multi-language sites", 
	'screenshot' => ""
	);
