#Batcher for ProcessWire
Batch Editing of pages in the ProcessWire Admin Panel
## Resources
* Forum Thread: http://processwire.com/talk/topic/2811-processbatcher/
* Module on the Processwire Modules page: http://modules.processwire.com/modules/process-batcher/

See the Forum Thread for instructions and screenshots