<?php

// Content regions
$title = $page->title;
$headline = $page->get("headline");
$content = $page->body;

// Project related (meta) settings
$config_seo_meta_title = $title;
$config_seo_meta_sitename = "Seitenname";
$config_seo_meta_description = "Seitenbeschreibung (meta)...";
$config_seo_meta_robots = "index,follow";

$config_canonical_url =  "http://tld.de".$input->url;

// Shared functions
include_once("./_func.php");

// Static template strings to translate
include_once("./_strings.php");
