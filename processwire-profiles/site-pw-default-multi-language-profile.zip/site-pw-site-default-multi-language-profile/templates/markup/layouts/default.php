

<?php if($page->repeat_module): ?>
<?php foreach($page->repeat_module as $item): ?>
    <?php
    if ($item->image_direction->value == 'left') {
      $direction = 'left';
    } elseif ($item->image_direction->value == 'right') {
      $direction = 'right';
    } else {
      $direction = 'left';
    }
    ?>
  <div class='box page-cke clearfix u-divider'>
    <?php if($item->image): ?>
    <p class="box__img box__img-<?php echo $direction; ?>">
      <img src="<?php echo $item->image->url; ?>" />
    </p>
    <?php endif; ?>
    <div class='box__body'>
      <?php echo $item->body_simple; ?>
    </div>
  </div>
<?php endforeach; ?>
<?php endif; ?>
