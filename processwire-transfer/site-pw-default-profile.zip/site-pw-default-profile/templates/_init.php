<?php

// Content regions
$title = $page->title;
$headline = $page->get("headline");
$content = $page->body;

// Settings
$canonical_url =  "http://tld.de".$input->url;

// Shared functions
include_once("./_func.php");
