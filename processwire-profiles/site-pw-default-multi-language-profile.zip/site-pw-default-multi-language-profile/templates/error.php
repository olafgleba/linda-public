<?php

// Layout specific variables
$page->main_headline = $headline;
$page->main_body = $content;


// Apply layout file
$page->layout = "one-column";

// Include frame markup
include("./markup/index.php");
