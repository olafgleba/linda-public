<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "PW Default Multi Language Profile", 
	'summary' => "Processwire Default Profile (Multi language)", 
	'screenshot' => ""
	);
