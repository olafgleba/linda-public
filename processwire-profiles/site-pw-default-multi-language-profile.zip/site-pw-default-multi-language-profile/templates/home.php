<?php

// Layout specific variables
$page->main_headline = $headline;
$page->main_body_main = $page->body_main;
$page->main_body_sidebar = $page->body_sidebar;

// Apply layout file
$page->layout = "two-column";

// Include frame markup
include("./markup/index.php");
