<?php namespace ProcessWire; ?>
<?php
/**
 * Guestbook entry form
 *
 */

// Form recipient
$emailTo = 'og@olafgleba.de';

// Default subject line
$emailSubject = "[{$config->httpHost}] Neuer Gästebucheintrag";

// Emitted before the form
$formHint = "<p class='c-form__note'>Mit einem Stern (*) markierten Felder sind Pflichtfelder und müssen ausgefüllt werden. Eure E-Mail Adresse wird <em>nicht</em> veröffentlicht.</p><p>Probleme mit dem Formular? Bitte schreibt uns <a href='mailto:og@olafgleba.de?subject=Gästebuchformular'>eine E-Mail</a>.\n";

// Emitted after form has been sent
$formConfirm = "<p>Ihre Nachricht wurde erfolgreich versandt.</p>\n";

// Emitted if not all required fields have been filled out
$requiredFields = "<p>Bitte überprüfen Sie, ob alle Pflichtfelder korrekt ausgefüllt wurden.</p>\n";


// Set and sanitize our form field values
$form = array(
    'name' => $sanitizer->text($input->post->name),
    'email' => $sanitizer->email($input->post->email),
    'mesg' => $sanitizer->textarea($input->post->mesg)
);

// Initialize runtime vars
$sent = false;
$error = '';
$markup = '';

// Secondary content: contact form
// if(!$input->post->submit) {
//   // If form was not yet submitted
//   //$markup .= $formHint;
// }

// Check if form was submitted
if($input->post->submit) {

  if(empty($input->post->fullname) || $input->post->fullname == '') {

    // Check if site is empty
    //if(!empty($form[site])) $error = $requiredFields;
    // Determine if any fields were ommitted or didn't validate
    // foreach($form as $key => $value) {
    //   if(!$form[sec]) {
    //     if(empty($value)) $error = $requiredFields;
    //   }
    // }
    // No errors, email the form results
    //if(!$error) {

      $message  = '';
      $message .= "Am ".date('d.m.Y \u\m H:i \U\h\r')." schrieb ";
      $message .= "$form[name] ($form[email]) folgende Nachricht ins Gästebuch:\n\n";
      $message .= "$form[mesg]";

      $mail = wireMail();

      $mail->to(array($emailTo));
      $mail->subject($emailSubject);
      $mail->body($message);
      //$mail->addSignature(true);

      $mailSent = $mail->send();

      // $entry = new Page();
      // $entry->template = 'guestbook-entry';
      // $entry->parent = $pages->get('/gaestebuch/');
      // $entry->title = $form['name'].",".date("d.m.Y H:i:s");
      // $entry->guestbook_name = $form['name'];
      // $entry->guestbook_message = $form['mesg'];
      // $entry->guestbook_email = $form['email'];
      // $entry->guestbook_date = date("d.m.Y");
      // $entry->save();

      $sent = true;
    //}

  } else {
    // Spam detected, so we simply redirect to home page
    $session->redirect($config->urls->root);

    // $markup .= "<p>".$input->post->fullname." ist ausgefüllt. Mail wird nicht geschickt...</p>";
  }
}

if($sent) {
    //$markup .= $formConfirm;
    // Redirect to first guestbook page, e.g. show new entry
    $session->redirect($config->urls->root."gaestebuch#frame-content", false);

    // $markup .= "<p>".$input->post->fullname." Mail kann geschickt werden...</p>";

} else {
    // Encode values for placement in markup
    foreach($form as $key => $value) {
        $form[$key] = htmlentities($value, ENT_QUOTES, "UTF-8");
    }
    // Emit the form
    $markup .= $error;
    $markup .= "<form class='c-form' id='guestbook-form' action='./' method='post'>\n";
    $markup .= "<div class='c-form__field c-form__field__highlight'>\n";
    $markup .= "<label for='fname'>Name*</label>\n";
    $markup .= "<input id='fname' name='name' type='text' autocomplete='off' value='' placeholder='Bsp. Else Killefit' required>\n";
    $markup .= "</div>\n";
    $markup .= "<div class='c-form__field'>\n";
    $markup .= "<label for='ffullname'>Wenn ihr mit assistiven Geräten das Formular ausfüllt, lasst dieses Feld bitte leer</label>\n";
    $markup .= "<input id='ffullname' name='fullname' type='text' autocomplete='off' value=''>\n";
    $markup .= "</div>\n";
    $markup .= "<div class='c-form__field'>\n";
    $markup .= "<label for='femail'>E-Mail-Adresse*</label>\n";
    $markup .= "<input id='femail' name='email' type='email' autocomplete='off' value='' placeholder='Bsp. else.killefit@example.de' required>\n";
    $markup .= "</div>\n";
    $markup .= "<div class='c-form__field'>\n";
    $markup .= "<label for='fmesg'>Nachricht*</label>\n";
    $markup .= "<textarea id='fmesg' name='mesg' rows='10' required></textarea>\n";
    $markup .= "</div>\n";
    $markup .= "<input name='submit' type='submit' class='button button--submit' value='Eintrag senden'>\n";
    $markup .= "</form>\n";
    $markup .= $formHint;
}

echo $markup;
