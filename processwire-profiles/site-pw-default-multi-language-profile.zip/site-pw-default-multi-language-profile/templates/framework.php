<?php

// Apply layout file
$page->layout = "framework";

// Include frame markup
include("./markup/framework.php");
