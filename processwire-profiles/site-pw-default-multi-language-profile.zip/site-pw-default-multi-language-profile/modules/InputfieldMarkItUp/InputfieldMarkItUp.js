$(document).ready(function() {

	$('.InputfieldMarkItUp textarea').markItUp(mySettings);


// $(".module .links a").click(function() {
// 	href = $(this).attr("href");
// 	title = $(this).attr("title");
// 	$.markItUp(
// 		{ openWith:'<a href="'+href+'" title="'+title+'">',
// 		  closeWith:'</a>',
// 		  placeHolder:title }
// 	);
// 	return false;
// });


});