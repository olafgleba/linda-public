<?php

/**
 * Static translated template strings to use project wide
 * in any templates. This spares us defining page fields
 * for every piece of code that doesn't have to be editable
 * within the admin interface. The function doesn't need to
 * execute with PHP, so we wrap it in a comment leaving
 * the code only visible to the language parser.
 *
 * Relies on function `_t` (`_func.php`)
 *
 * Usage:
 * 1. Define string in markup, e.g. <?php echo _t('<string>', '<context');?>
 * 2. Insert string in _strings.php, e.g. _x('<string>', '<context');
 * 3. Choose the language you like to translate the default language strings
 * 4. Add or modify site translation files (Admin > Languages >
 *    site--templates--_strings-php.json) and translate phrases/strings
 */

/*!


*/
