// -------------------------------------------------------------------
// markItUp!
// -------------------------------------------------------------------
// Copyright (C) 2008 Jay Salvat
// http://markitup.jaysalvat.com/
// -------------------------------------------------------------------
// Textile tags example
// http://en.wikipedia.org/wiki/Textile_(markup_language)
// http://www.textism.com/
// -------------------------------------------------------------------
// Feel free to add more tags
// -------------------------------------------------------------------
mySettings = {
	nameSpace: "textile",
	previewParserPath:	'', // path to your Textile parser
	onShiftEnter:		{keepDefault:false, replaceWith:'\n\n'},
	markupSet: [
		{name:'Heading 1', key:'1', openWith:'h1(!(([![Class]!]))!). ', placeHolder:'Your title here...' },
		{name:'Heading 2', key:'2', openWith:'h2(!(([![Class]!]))!). ', placeHolder:'Your title here...' },
		{name:'Heading 3', key:'3', openWith:'h3(!(([![Class]!]))!). ', placeHolder:'Your title here...' },
		{name:'Heading 4', key:'4', openWith:'h4(!(([![Class]!]))!). ', placeHolder:'Your title here...' },
		{name:'Heading 5', key:'5', openWith:'h5(!(([![Class]!]))!). ', placeHolder:'Your title here...' },
		{name:'Heading 6', key:'6', openWith:'h6(!(([![Class]!]))!). ', placeHolder:'Your title here...' },
		{name:'Paragraph', key:'P', openWith:'p(!(([![Class]!]))!). '},
		{separator:'---------------' },
		{name:'Bold', key:'B', closeWith:'*', openWith:'*'},
		{name:'Italic', key:'I', closeWith:'_', openWith:'_'},
		{name:'Stroke through', key:'S', closeWith:'-', openWith:'-'},
		{separator:'---------------' },
		{name:'Bulleted list', openWith:'(!(* |!|*)!)'},
		{name:'Numeric list', openWith:'(!(# |!|#)!)'},
		{separator:'---------------' },
		{name:'Picture', replaceWith:'![![Source:!:http://]!]([![Alternative text]!])!'},
		{name:'Link', openWith:'"', closeWith:'([![Title]!])":[![Link:!:http://]!]', placeHolder:'Your text to link here...' },
		{separator:'---------------' },
    {name:'Pictures',
     className:'pictures',
     		beforeInsert:function() {
						var windowHeight = $(window).height() - 350;
						var windowWidth = $(window).width() - 200;

						var pageID = $("#Inputfield_id").val();

						var modalUrl = config.urls.admin + 'page/image/?id=' + pageID + '&modal=1';

            $('<iframe src="' + modalUrl + '"></iframe>').dialog({
            	height: windowHeight,
            	width: windowWidth,
            	position: [100, 80],
            	modal: true
            });
        }
    },
    {name:'Internal Link',
     className:'links',
     		beforeInsert:function() {
						var windowHeight = $(window).height() - 250;
						var windowWidth = $(window).width() - 250;

						var pageID = $("#Inputfield_id").val();

						var modalUrl = config.urls.admin + 'page/link/?id=' + pageID + '&modal=1';

            $iframe = $('<iframe id="pwlink_iframe" src="' + modalUrl + '"></iframe>');



            //console.log(editor);

						var href = '';
						var target = '';


						//console.log(txtarea);

						// init
						var text = '';

						// var selObj = window.getSelection();
						// var range = selObj.getRangeAt(0);
						// window.alert(selObj + ': ' + range);

						//alert(txtarea.selectionStart);

						if (typeof document.getSelection() != 'undefined') {
							//console.log("document.getSelection() aktiv");

							var selection = document.getSelection();
							//alert(selection);
						}
						// else if (typeof txtarea.selectionStart != 'undefined') {
						// 	console.log("txtarea.selectionStart aktiv");
						// }



            // if ('selectionStart' in txtarea) {
            //         // check whether some text is selected in the textarea
            //     if (txtarea.selectionStart != txtarea.selectionEnd) {
            //         selection = txtarea.value.substring  (txtarea.selectionStart, txtarea.selectionEnd);
            //     }
            // }

            // if (selection == "") {
            //     console.log("No text is selected.");
            // }
            // else {
            //     console.log("The current selection is: " + selection);
            // }



						// if (window.getSelection) {
						// 	var selectionRange = window.getSelection();
						// 	console.log("window.getSelection:" + selectionRange.toString());
						// }


						// if(document.selection) {
						// 	console.log('document.selection is available');
						// 	var theSelection = document.selection.createRange().text;
						// 	text = theSelection;
						// } else if(txtarea.selectionStart || txtarea.selectionStart == '0') {
						// 	console.log('document.selection is partly available');
					 // 		var startPos = txtarea.selectionStart;
						// 	var endPos = txtarea.selectionEnd;
						// 	text = (txtarea.value).substring(startPos, endPos);
						// } else {
						// 	text = 'debug';
						// 	console.log('document.selection is not available');
						// }

						//console.log(text);
						//return unescape(encodeURIComponent(text));

						// var selection = text;

						// s.o., var selection = document.getSelection();

						//var selectionElement = selection.

						//var selectionText = selection.getRangeAt(0);


						//txtarea = $('.markItUpEditor').name;

						txtarea = document.ProcessPageEdit.test;

						//txtarea = $(txtarea);

						//var txtarea = $(txtareaName);

						//var txtarea = $('#Inputfield_test');

						//alert(txtarea);

				 		var startPos = txtarea.selectionStart;
						var endPos = txtarea.selectionEnd;
						selectionText = (txtarea.value).substring(startPos, endPos);

						//alert(startPos);

						// var selectionElement = selection.getSelectedElement();
						// var node = selection.getStartElement();
						// var selectionText = selection.getSelectedText();

						// var selection = editor.getSelection(true);
						// var selectionElement = selection.getSelectedElement();
						// var node = selection.getStartElement();
						// var selectionText = selection.getSelectedText();


						// if(node.getName() == 'a') {
						// 	href = node.getAttribute('href');
						// 	target = node.getAttribute('target');
						// 	selection.selectElement(node);
						// 	selectionText = node.getHtml();

						// } else if(node.getName() == 'img') {
						// 	var $img = $(node.$);
						// 	href = $img.parent("a").attr("href");
						// 	selectionText = node.$.outerHTML;

						// } else if (selectionText.length < 1) {
						// 	// If not on top of link and there is no text selected - just return (don't load iframe at all)
						// 	return;
						// }

						$iframe.load(function() {
							var $i = $iframe.contents();
							$i.find("#link_page_url").val(href);
							$i.find("#ProcessPageEditLinkForm").data('iframe', $iframe);
							if(target && target.length) $i.find("#link_target").attr('checked', 'checked');
						});


      			$iframe.dialog({
            	height: windowHeight,
            	width: windowWidth,
            	//position: [150, 80],
            	modal: true,
							overlay: {
								opacity: 0.7,
								background: "black"
							},
							buttons: [
								{
									text: 'Insert Link',
									click: function() {

										var $i = $iframe.contents();
										var url = $("#link_page_url", $i).val();
										var target = $("#link_target", $i).is(":checked") ? "_blank" : '';

										if(target && target.length > 0) target = ' target="' + target + '"';
										if(url.length) {
											var html = '<a href="' + url + '"' + target + '>' + selectionText + '</a>';
											//editor.insertHtml(html);
											console.log(html);
										}
										$iframe.dialog("close");
									}
								},
								{
									text: 'Close Window',
									click: function() { $iframe.dialog("close"); }
								}
							]
            });
        }
    },
		{separator:'---------------' },
		{name:'Quotes', openWith:'bq(!(([![Class]!]))!). '},
		{name:'Code', openWith:'@', closeWith:'@'}
	]
}