<?php

// Layout specific variables
$page->main_headline = $headline;
$page->main_body_main = $page->body_main;


// Apply layout file
$page->layout = "one-column";

// Include frame markup
include("./markup/index.php");
