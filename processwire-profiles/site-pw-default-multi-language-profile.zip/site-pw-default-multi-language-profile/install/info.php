<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "PW Default Multi Language Profile", 
	'summary' => "This is the PW Default Multi Language Profile", 
	'screenshot' => ""
	);
