<?php

/**
 * Static translated template strings to use project wide
 * in any templates. This spares us defining page fields
 * for every piece of code that doesn't have to be editable
 * within the admin interface. The function doesn't need to
 * execute with PHP, so we wrap it in a comment leaving
 * the code only visible to the language parser.
 *
 * Relies on function `_t` (`_func.php`)
 *
 * Usage:
 * 1. Define string in markup, e.g. <?php echo _t('<string>', '<context>');?>
 * 2. Insert string in _strings.php, e.g. \_x('<string>', '<context>');
 *    without the leading "\". This just to avoid this comment is parsed.
 * 3. Choose the language you like to translate the default language strings
 * 4. Under (the still empty) "Site Translation Files" click on "Translate File" to get
 *    a list of translatable files. Choose the _strings.php and click send/save. You'll
 *    see the translatable string phrases.
 */

/*!


*/
