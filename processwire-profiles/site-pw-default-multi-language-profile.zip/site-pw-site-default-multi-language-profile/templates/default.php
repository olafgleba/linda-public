<?php

// Apply layout file
$page->layout = "default";

// Include frame markup
include("./markup/index.php");
