<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Processwire Standard Profil", 
	'summary' => "Multilinguales Processwire Profil", 
	'screenshot' => ""
	);
